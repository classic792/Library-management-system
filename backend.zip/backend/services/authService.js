import jwt from "jsonwebtoken";
import User from "../models/User.js";
import { comparePassword } from "../utils/passwordHash.js";

const sanitizeUser = (userDoc) => {
  const user = userDoc.toObject();
  delete user.password;
  delete user.confirmPassword;
  return user;
};

const generateToken = (userId, role) => {
  const secret = process.env.JWT_SECRET || "dev-secret";
  //activate this line in production and remove "dev-secret" above
  // TODO:if (!secret) throw new Error('Missing JWT_SECRET');
  const expiresIn = process.env.JWT_EXPIRES_IN || "1d";
  return jwt.sign({ sub: userId, role }, secret, { expiresIn });
};

const throwHttpError = (message, statusCode) => {
  const error = new Error(message);
  error.statusCode = statusCode;
  throw error;
};

export const registerUser = async (payload) => {
  const { email, alias } = payload;
  const existingUser = await User.findOne({
    $or: [{ email }, { alias }],
  });
  if (existingUser) {
    throwHttpError("User with provided email or alias already exists", 409);
  }

  const newUser = await User.create({
    ...payload,
    email,
    alias,
  });
  const token = generateToken(newUser._id, newUser.role);

  return {
    user: sanitizeUser(newUser),
    token,
  };
};

export const loginUser = async (payload) => {
  const raw =
    payload?.email ||
    payload?.alias ||
    payload?.identifier ||
    payload?.emailOrAlias;
  const password = payload?.password;
  const normalizedIdentifier = raw?.trim().toLowerCase();
  if (!normalizedIdentifier || !password)
    throwHttpError("Email/alias and password required", 400);
  const user = await User.findOne({
    $or: [{ email: normalizedIdentifier }, { alias: normalizedIdentifier }],
  }).select("+password");

  if (!user) {
    throwHttpError("Invalid Username", 401);
  }

  const isMatch = await comparePassword(password, user.password);
  if (!isMatch) {
    throwHttpError("Invalid Password", 401);
  }

  const token = generateToken(user._id, user.role);

  return {
    user: sanitizeUser(user),
    token,
  };
};
